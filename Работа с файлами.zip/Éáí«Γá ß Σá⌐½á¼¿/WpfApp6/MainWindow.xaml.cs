﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp6
{
  
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dig = new SaveFileDialog();
            dig.Filter = "Text File(*.txt)|*.txt|C# file (*.cs)|*.cs";
            if (dig.ShowDialog() == true)
            {
                
                File.WriteAllText(dig.FileName, tx1.Text);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            if (openFile.ShowDialog() == true)
            {
                string filename = openFile.FileName;
                string fileText = File.ReadAllText(filename);
                tx1.Text = fileText;
             
            }
        }
    }
    
}
